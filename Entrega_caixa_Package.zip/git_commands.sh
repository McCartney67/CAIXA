#!/bin/bash
# Example script to push files to GitHub (requires Git and gh CLI)
git init
git add .
git commit -m "Entrega CAIXA - análise estática, planilha e código"
# If you have GitHub CLI:
# gh repo create your-user/caixa --public --source=. --remote=origin --push
# OR manually add remote and push:
# git remote add origin https://github.com/your-user/caixa.git
# git branch -M main
# git push -u origin main
echo "Edite o script substituindo 'your-user' pelo seu usuário GitHub e execute."
