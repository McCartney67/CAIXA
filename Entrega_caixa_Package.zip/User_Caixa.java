package caixa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Classe User (CAIXA) - versão comentada, com práticas de segurança:
 *  - Usa PreparedStatement para evitar SQL Injection.
 *  - Usa try-with-resources para fechar recursos automaticamente.
 *  - Credenciais obtidas via variáveis de ambiente (não hardcoded).
 *
 * Para testar localmente, configure as variáveis de ambiente DB_USER e DB_PASS,
 * e tenha uma tabela `usuarios(login, senha, nome)` no banco de desenvolvimento.
 */
public class User_Caixa {

    // Nome do usuário autenticado
    private String usuarioNome = "";

    // Indica se a autenticação foi bem sucedida
    private boolean usuarioValido = false;

    /**
     * Abre conexão com o banco de dados.
     * NOTA: em produção, use um pool de conexões (HikariCP, etc.).
     */
    public Connection conectarBD() {
        Connection conn = null;
        try {
            // Driver moderno do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1:3306/test";
            // Preferível pegar credenciais de forma segura (variáveis de ambiente)
            String user = System.getenv("DB_USER");
            String pass = System.getenv("DB_PASS");
            if (user == null) user = "lopes"; // fallback local (apenas para dev)
            if (pass == null) pass = "123";
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            // Registre o erro para análise (evite swallow exceptions)
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * Verifica usuário usando PreparedStatement para evitar injeção de SQL.
     * O método é testável: comporta conexão nula (retorna false) e fecha recursos.
     *
     * @param login login do usuário
     * @param senha senha do usuário
     * @return true se usuário autenticado, false caso contrário
     */
    public boolean verificarUsuario(String login, String senha) {
        String sql = "SELECT nome FROM usuarios WHERE login = ? AND senha = ?";
        try (Connection conn = conectarBD()) {
            if (conn == null) {
                System.err.println("Falha ao conectar ao BD.");
                return false;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, login);
                ps.setString(2, senha);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        // usuário encontrado
                        usuarioNome = rs.getString("nome");
                        usuarioValido = true;
                    } else {
                        usuarioValido = false;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            usuarioValido = false;
        }
        return usuarioValido;
    }

    public String getUsuarioNome() {
        return usuarioNome;
    }
}
