import caixa.User_Caixa;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/*
This test uses Mockito to mock the database interaction and validate behavior
of verificarUsuario without requiring a real DB connection.
To run:
- Add dependencies: junit-jupiter-api, mockito-core
- Compile and run with your build tool (Maven/Gradle)
*/
public class TestUserCaixa {

    @Test
    public void testVerificarUsuario_UserFound() throws Exception {
        // mock objects
        Connection conn = mock(Connection.class);
        PreparedStatement ps = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);

        // stubbing
        when(conn.prepareStatement(anyString())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true);
        when(rs.getString("nome")).thenReturn("Aluno Teste");

        // Partial spy: create an instance and override conectarBD to return our mock connection
        User_Caixa user = Mockito.spy(new User_Caixa());
        doReturn(conn).when(user).conectarBD();

        boolean result = user.verificarUsuario("login", "senha");
        assertTrue(result);
        assertEquals("Aluno Teste", user.getUsuarioNome());
    }

    @Test
    public void testVerificarUsuario_UserNotFound() throws Exception {
        Connection conn = mock(Connection.class);
        PreparedStatement ps = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);

        when(conn.prepareStatement(anyString())).thenReturn(ps);
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(false);

        User_Caixa user = Mockito.spy(new User_Caixa());
        doReturn(conn).when(user).conectarBD();

        boolean result = user.verificarUsuario("login", "senha");
        assertFalse(result);
        assertEquals("", user.getUsuarioNome());
    }
}
